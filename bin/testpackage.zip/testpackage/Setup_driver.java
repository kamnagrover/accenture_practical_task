package testpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Setup_driver {
	public static WebDriver driver = new ChromeDriver();
	public void launch() {	
    System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");
	//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 			//implicit wait
	driver.get("https://www.amazon.com/");
	driver.manage().window().maximize();
	}
}
