package testpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class locators extends baseClass {
	
	//initializing
	public  WebElement addToCart	= driver.findElement(By.id("add-to-cart-button"));
	public  WebElement incart = driver.findElement(By.xpath("//*[@class='a-button-text' and @href='/gp/cart/view.html?ref_=ewc_gtc']"));
	public  WebElement searchbox = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox' and @type='text']"));
	public  WebElement searchsubmit = driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
	public  WebElement filter = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']//child::span[contains(text(),'Sort by:')]"));
	public  WebElement descorder = driver.findElement(By.xpath("//li/a[contains(text(), 'Price: High to Low') and @id='s-result-sort-select_2']"));
	public  WebElement checkItems = driver.findElement(By.xpath("//*[@id='sc-subtotal-label-activecart']"));

	public  String URL="https://www.amazon.com/";
	public  String product="selenium hardcover book";
	public  int i=1;

}
