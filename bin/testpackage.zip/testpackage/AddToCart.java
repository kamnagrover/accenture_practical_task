package testpackage;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.*;
import org.testng.Assert;


public class AddToCart extends baseClass{

	locators locators = new locators();
	
  @Test(priority=0)
  public void verfyTitle() {
	  
		//checking the page title
		String expectedtitle="Amazon.com. Spend less. Smile more.";
		System.out.println(driver.getTitle());
		Assert.assertEquals(driver.getTitle(), expectedtitle);
  }
  
  
  @Test(priority=1)
  public void search() {
	
		//search for the product
	  locators.searchbox.sendKeys(locators.product);
	  locators.searchsubmit.click();
		
		//Select Price Filter: High to low
	  locators.filter.click();
	  locators.descorder.click();
  }
  
  
  @Test(priority=2)
  public void selectelement() {
		//call search function
		search();
		//select first element & add to cart
		driver.findElement(By.xpath("//img[@data-image-index='"+locators.i+"']")).click();
		locators.addToCart.click();
		locators.i=locators.i+1;
  }
  
  
  @Test(priority=3)
  public void anotherelement() {
	  	//repeat process for second element
	  	//select second element & add to cart
	  	selectelement();
  }
  
  
  @Test(priority=4)
  public void verifycart() {
	  	//check the number of items in cart
	  locators.incart.click();	
	  String check= locators.checkItems.getText();
	  System.out.println(check);
	  	Assert.assertEquals(check, "Subtotal (2 items):");
  }
  
	
}
