package testpackage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class baseClass {
	public WebDriver driver= new ChromeDriver();
	@BeforeMethod
		
		public void launch() {	
	    System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 			//implicit wait
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		}
	@AfterMethod
	public void close(){
		driver.close();
	}
}
